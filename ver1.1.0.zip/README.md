## name
stallionScrape

## Overview
This is scraping tool for [shuboba profile](http://keiba.no.coocan.jp/).  
As a first release, collecting crop's results of stallion horse.

## Requirement
Windows10 ~  

## Usage
1. Download zip or pull repository.
2. Execute below on cmd.
   ```
   npm install
   npm start
   ```
3. Press "Get Crops Results" button.
4. All finished, csv file will be on desktop.

## Features
+ You can change default language to English by pressing "Config" button and checkout "japanese".
  
## Author
N3-Uchimura

## Licence
[MIT](https://mit-license.org/)
