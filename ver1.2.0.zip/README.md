<table>
	<thead>
    	<tr>
      		<th style="text-align:center">English</th>
      		<th style="text-align:center"><a href="README-ja.md">日本語</a></th>
    	</tr>
  	</thead>
</table>

## name

stallionScrape

## Overview

This is scraping tool for [shuboba profile](http://keiba.no.coocan.jp/).

## Requirement

Windows10 ~

## Setting

### From souce

1. Download zip or pull repository.
2. Execute below on cmd.
   ```
   npm install
   npm start
   ```

### From exe

1. Download exe file from release.
2. DoubleClick on exe file and install.

## Usage

1. Press "Get Stallions" button.
2. All finished, csv file will be on desktop.

## Features

- You can change default language to English by pressing "Config" button and checkout "japanese".

## Author

N3-Uchimura

## Licence

[MIT](https://mit-license.org/)
